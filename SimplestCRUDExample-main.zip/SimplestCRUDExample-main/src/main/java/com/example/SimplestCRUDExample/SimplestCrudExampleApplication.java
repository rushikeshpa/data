package com.example.SimplestCRUDExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplestCrudExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimplestCrudExampleApplication.class, args);
	}

}
